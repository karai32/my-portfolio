import "./BlogPost.css"

const BlogPost = ({title, text}) => {
    return(
        <article>
            <div>
                <div>

                </div>
                <h3>
                    {title}
                </h3>
            </div>
            <p>{text}</p>
        </article>
    )
}

export default BlogPost