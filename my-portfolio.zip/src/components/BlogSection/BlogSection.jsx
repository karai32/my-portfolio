import React from "react";
import BlogPost from "../BlogPost/BlogPost";
import { useTranslation } from "react-i18next";

const BlogSection = () => {
    const { t } = useTranslation();

    // Теперь просто t("posts"), потому что JSON — это массив
    const posts = t("posts", { returnObjects: true });

    console.log("Загруженные посты:", posts); // ✅ Проверка в консоли

    return (
        <section>
            <h2>{t("blog_title")}</h2>
            {Array.isArray(posts) && posts.length > 0 ? (
                posts.map((post) => (
                    <BlogPost key={post.id} title={post.title} text={post.text} />
                ))
            ) : (
                <p>Постов пока нет...</p> // Если массив пустой
            )}
        </section>
    );
};

export default BlogSection;
